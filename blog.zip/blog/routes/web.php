<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'departmentController@index');
Route::get('home/request/{employeeID}', 'departmentController@show');
Route::post('/edit_employee', 'departmentController@store');

Route::get('/encoder', 'encoderController@view');
Route::get('/request/{employeeID}', 'encoderController@show');
Route::post('/assign', 'encoderController@store');