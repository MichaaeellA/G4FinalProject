<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Assign extends Model
{
    protected $fillable = ['employeeID', 'fname', 'mname', 'department', 'doctor'];
}
