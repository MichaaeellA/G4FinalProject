<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
use App\Approve;

class departmentController extends Controller
{
    public function index()
    {
    	$emp = Employee::all();

    	return view('index' , compact('emp'));
    }

    public function show($employeeID)
    {

    	$employee = Employee::where('employeeID', $employeeID)->first();
    	// dd($employeeID);
    	return view('edit', compact('employee'));
    }

    public function store()
    {

    	request()->validate([
    		'employeeID'=> 'required',
    		'fname'=> 'required',
    		'mname'=> 'required',
    		'department'=> 'required',
    		'by'=> 'required',
    	]);

    	$approved = Approve::create([

    		'employeeID'=> request()->employeeID,
    		'fname'=> request()->fname,
    		'mname'=> request()->mname,
    		'department'=> request()->department,
    		'by'=> request()->by,
    	]);

    	return redirect('/encoder')->with('success', 'medical requested sucessfully sent');
    		
    }
}
