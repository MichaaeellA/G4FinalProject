<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Approve;
use App\Assign;

class encoderController extends Controller
{
    public function view()
    {
    	$approved = Approve::all();
    	// dd($approved);
    	return view('approve', compact('approved'));
    }


    public function show($employeeID)
    {

    	$employee = Approve::where('employeeID', $employeeID)->first();
    	// dd($employeeID);
    	return view('assign', compact('employee'));
    }

    public function store()
    {
    	request()->validate([
    		'employeeID'=> 'required',
    		'fname'=> 'required',
    		'mname'=> 'required',
    		'department'=> 'required',
    		'doctor'=> 'required',
    	]);

    	$assign = Assign::create([

    		'employeeID'=> request()->employeeID,
    		'fname'=> request()->fname,
    		'mname'=> request()->mname,
    		'department'=> request()->department,
    		'doctor'=> request()->doctor,
    	]);

    	return redirect('/encoder')->with('success', 'medical requested sucessfully sent');
    }
}
