<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Approve extends Model
{
    protected $fillable = ['employeeID', 'fname', 'mname', 'department', 'by'];
}
