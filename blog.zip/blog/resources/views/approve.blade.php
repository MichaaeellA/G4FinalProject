<!DOCTYPE html>
<html>
<head>
    <title>Departrment Head</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
        @if(session('success'))

        <div class="alert alert-success">
            {{session('success')}}
        </div>

    @endif

    @foreach($approved as $approved)

        <div class="row" style="margin-top: 1em; ">
               <div class="col-md-7 offset-md-3">
            <div class="card">
                <div class="card-title">Recieved Medical Form</div>
                <div class="card-body">
                    <a href="request/{{ $approved->employeeID }}">{{$approved->employeeID}}</a>
                    <br>
                    This is to request your kindly hospitality, to {{$approved->fname}} {{$approved->mname}}. that he/she is under my department: {{$approved->department}}.<br>

                    by: {{$approved->by}}<br>
                    recieved at: {{$approved->created_at}}
                </div>
            </div>
        </div>
        </div>

    @endforeach


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>