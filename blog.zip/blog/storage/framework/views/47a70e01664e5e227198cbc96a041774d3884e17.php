<!DOCTYPE html>
<html>
<head>
    <title>Departrment Head</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>

        <div class="row">
            <div class="col-md-4 offset-md-4">
                <form method="post" action="/assign">
                      <?php echo csrf_field(); ?>
                  <div class="form-group">
                      <label for="id">Employee ID</label>
                      <input type="text" name="employeeID" class="form-control" value="<?php echo e($employee->employeeID); ?>">
                  </div>
                  <div class="form-group">
                      <label for="fname">First Name</label>
                      <input type="text" name="fname" class="form-control" value="<?php echo $employee->fname?>">
                  </div>
                  <div class="form-group">
                      <label for="mname">Middle Name</label>
                      <input type="text" name="mname" class="form-control" value="<?php echo $employee->mname?>">
                  </div>
                  <div class="form-group">
                      <label for="fname">Department</label>
                      <input type="text" name="department" class="form-control" value="<?php echo $employee->department?>">
                  </div>
                  <div class="form-group">
                      <label for="fname">Physician</label>
                      <select name="doctor" class="form-control">
                          <option value="nurse1">Nurse1</option>
                          <option value="nurse2">Nurse2</option>
                      </select>
                  </div>
                  <button type="submit" class="btn btn-dark">Assign</button>
                </form>
                
            </div>
        </div>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/assign.blade.php ENDPATH**/ ?>